# Reddit Digest - Native Skill

Zero-dependency weekly Reddit digest generator using pure Python. No external tools required - just Python standard library + requests.

## Features

- 🚀 Zero external dependencies (except requests)
- 🎯 Fetch top posts from multiple subreddits
- 📝 Generate AI-powered Chinese summaries
- 📊 Create formatted Markdown reports
- 🔥 Highlight trending content
- ⏰ Weekly automated digests
- 🔒 Self-contained and auditable

## Installation

### Prerequisites

```bash
pip install requests
```

### Clone this skill

```bash
git clone https://github.com/Raymond-Hear/reddit-digest-native-skill.git
```

## Usage

### Quick Start

```bash
python3 scripts/reddit_fetcher.py --subreddits PromptEngineering,ClaudeAI,SideProject --limit 10
```

### Python API

```python
from scripts.reddit_fetcher import RedditFetcher

fetcher = RedditFetcher(delay=3.0)
posts = fetcher.fetch_subreddit("PromptEngineering", time_filter="week", limit=10)
```

### Default Subreddits

**AI/Tools:**
- r/PromptEngineering
- r/notebooklm
- r/ClaudeAI
- r/google
- r/Anthropic

**Business/Product:**
- r/SideProject
- r/Entrepreneur
- r/marketing

## Workflow

1. **Fetch posts** using native Python requests
2. **Parse JSON** from Reddit's public API
3. **Generate Chinese summaries** using AI
4. **Create Markdown report** with formatted output
5. **Save report** to output directory

## Script Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `--subreddits` | Comma-separated list of subreddit names | (8 default subs) |
| `--time-filter` | Time range: hour/day/week/month/year | week |
| `--limit` | Max posts per subreddit | 10 |
| `--delay` | Seconds between requests | 3 |
| `--output` | Output directory | ./reddit_data |
| `--format` | Output format: json/csv/both | both |

## Output Format

```markdown
# 📰 Reddit 每周精选 — YYYY-MM-DD

## 🤖 r/SubredditName

**🔥 Post Title** — X upvotes · Y comments
Chinese summary here
https://reddit.com/...

---

## 📊 本周热点趋势
```

## Implementation

### RedditFetcher Class

```python
class RedditFetcher:
    """Fetch Reddit posts without external dependencies."""
    
    def fetch_subreddit(self, subreddit: str, time_filter: str, limit: int) -> List[Dict]:
        """Fetch top posts from a subreddit."""
        
    def fetch_multiple(self, subreddits: List[str], time_filter: str, limit: int) -> Dict:
        """Fetch posts from multiple subreddits."""
```

### Features

- Uses only Python standard library + requests
- Fetches from `https://www.reddit.com/r/{subreddit}/top/.json?t=week`
- Implements rate limiting and retry logic
- No external dependencies beyond requests
- Clean, auditable code

## OpenClaw Integration

This is an OpenClaw skill. Place in your skills directory:

```
~/.openclaw/skills/reddit-digest-native/
├── SKILL.md
├── README.md
└── scripts/
    └── reddit_fetcher.py
```

## Why Native?

| Aspect | Native | ScrapiReddit |
|--------|--------|--------------|
| Dependencies | Just requests | Full package |
| Code control | Full | Limited |
| Auditability | Easy | Moderate |
| Updates | Manual | Automatic |
| Setup | Simple | Simple |

Choose **native** when you need:
- Maximum control over the code
- Easy security auditing
- No dependency management
- Restricted environments

## License

MIT

## Credits

- Created for OpenClaw AI assistant
- Pure Python implementation for maximum portability
