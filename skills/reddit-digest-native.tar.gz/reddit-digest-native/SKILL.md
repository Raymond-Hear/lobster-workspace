---
name: reddit-digest-native
description: Weekly Reddit digest generator with zero dependencies. Pure Python implementation using requests to fetch Reddit JSON API. Use when user needs (1) Reddit content digests without installing external tools, (2) a self-contained solution that works in restricted environments, (3) automated Reddit monitoring without pip dependencies.
---

# Reddit Digest - Native Edition

Zero-dependency Reddit digest generator using pure Python.

## Usage

### Quick Start

Run the embedded script to fetch and generate digest:

```bash
python3 scripts/reddit_fetcher.py --subreddits PromptEngineering,ClaudeAI,SideProject --limit 10
```

### Python API

```python
from scripts.reddit_fetcher import RedditFetcher

fetcher = RedditFetcher(delay=3.0)
posts = fetcher.fetch_subreddit("PromptEngineering", time_filter="week", limit=10)
```

## Default Subreddits

AI/Tools:
- r/PromptEngineering
- r/notebooklm
- r/ClaudeAI
- r/google
- r/Anthropic

Business/Product:
- r/SideProject
- r/Entrepreneur
- r/marketing

## Workflow

1. **Fetch posts** using native Python requests
2. **Parse JSON** from Reddit's public API
3. **Generate Chinese summaries** using AI
4. **Create Markdown report** with formatted output
5. **Save to** `/root/.openclaw/workspace/output/reddit-digest-YYYY-MM-DD.md`

## Script Parameters

- `--subreddits`: Comma-separated list of subreddit names
- `--time-filter`: week (default), day, month, year
- `--limit`: max posts per subreddit (default: 10)
- `--delay`: seconds between requests (default: 3)
- `--output`: output directory (default: ./reddit_data)

## Output Format

```markdown
# 📰 Reddit 每周精选 — YYYY-MM-DD

## 🤖 r/SubredditName

**🔥 Post Title** — X upvotes · Y comments
Chinese summary here
https://reddit.com/...

---

## 📊 本周热点趋势
```

## Implementation Notes

- Uses only Python standard library + requests
- Fetches from `https://www.reddit.com/r/{subreddit}/top/.json?t=week`
- Implements rate limiting and retry logic
- No external dependencies beyond requests
