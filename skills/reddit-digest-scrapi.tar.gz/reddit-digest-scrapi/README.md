# Reddit Digest - ScrapiReddit Skill

Weekly Reddit digest generator using [ScrapiReddit](https://github.com/rodneykeilson/ScrapiReddit). Fetches top posts from specified subreddits, generates Chinese summaries, and creates a formatted Markdown report.

## Features

- 🎯 Fetch top posts from multiple subreddits
- 📝 Generate AI-powered Chinese summaries
- 📊 Create formatted Markdown reports
- 🔥 Highlight trending content
- ⏰ Weekly automated digests

## Installation

### Prerequisites

```bash
pip install scrapi-reddit
```

### Clone this skill

```bash
git clone https://github.com/Raymond-Hear/reddit-digest-scrapi-skill.git
```

## Usage

### Basic Command

```bash
scrapi-reddit <subreddit> --time-filter week --limit 10 --delay 3 --output-format both
```

### Example: Fetch single subreddit

```bash
scrapi-reddit PromptEngineering --time-filter week --limit 10 --delay 3 --output-format both
```

### Default Subreddits

**AI/Tools:**
- r/PromptEngineering
- r/notebooklm
- r/ClaudeAI
- r/google
- r/Anthropic

**Business/Product:**
- r/SideProject
- r/Entrepreneur
- r/marketing

## Workflow

1. **Fetch posts** for each subreddit using ScrapiReddit
2. **Read JSON files** from `./scrapi_reddit_data/`
3. **Generate Chinese summaries** using AI
4. **Create Markdown report** with:
   - Group by subreddit
   - Title + link + upvotes + comments
   - Chinese summary (1-2 sentences)
   - Highlight top posts with 🔥
5. **Save report** to output directory

## Output Format

```markdown
# 📰 Reddit 每周精选 — YYYY-MM-DD

## 🤖 r/SubredditName

**🔥 Post Title** — X upvotes · Y comments
Chinese summary here
https://reddit.com/...

---

## 📊 本周热点趋势

| 趋势 | 说明 |
|:---|:---|
```

## Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `--time-filter` | Time range: hour/day/week/month/year | week |
| `--limit` | Max posts per subreddit | 10 |
| `--delay` | Seconds between requests (min: 1) | 3 |
| `--output-format` | Output format: json/csv/both | both |

## OpenClaw Integration

This is an OpenClaw skill. Place in your skills directory:

```
~/.openclaw/skills/reddit-digest-scrapi/
├── SKILL.md
└── (optional resources)
```

## Notes

- ScrapiReddit fetches from Reddit's public JSON API
- No Reddit API key required
- Respect rate limits (3+ seconds delay recommended)
- Data saved to `./scrapi_reddit_data/` by default

## License

MIT

## Credits

- [ScrapiReddit](https://github.com/rodneykeilson/ScrapiReddit) by rodneykeilson
- Created for OpenClaw AI assistant
