---
name: reddit-digest-scrapi
description: Weekly Reddit digest generator using ScrapiReddit. Fetches top posts from specified subreddits, generates Chinese summaries, and creates a formatted Markdown report. Use when user needs to (1) generate weekly Reddit content digests, (2) monitor specific subreddits for trending content, (3) create automated Reddit reports with AI-generated summaries.
---

# Reddit Digest - ScrapiReddit Edition

Generate weekly Reddit digests using ScrapiReddit tool.

## Prerequisites

ScrapiReddit must be installed:
```bash
pip install scrapi-reddit
```

## Usage

### Basic Command

```bash
scrapi-reddit <subreddit> --time-filter week --limit 10 --delay 3 --output-format both
```

### Default Subreddits

AI/Tools:
- r/PromptEngineering
- r/notebooklm
- r/ClaudeAI
- r/google
- r/Anthropic

Business/Product:
- r/SideProject
- r/Entrepreneur
- r/marketing

### Workflow

1. **Fetch posts for each subreddit:**
   ```bash
   scrapi-reddit PromptEngineering --time-filter week --limit 10 --delay 3 --output-format both
   ```

2. **Read the generated JSON files** from `./scrapi_reddit_data/`

3. **Generate Chinese summaries** for each post using AI

4. **Create Markdown report** with:
   - Group by subreddit
   - Title + link + upvotes + comments
   - Chinese summary (1-2 sentences)
   - Highlight top posts with 🔥

5. **Save to** `/root/.openclaw/workspace/output/reddit-digest-YYYY-MM-DD.md`

### Output Format

```markdown
# 📰 Reddit 每周精选 — YYYY-MM-DD

## 🤖 r/SubredditName

**🔥 Post Title** — X upvotes · Y comments
Chinese summary here
https://reddit.com/...

---

## 📊 本周热点趋势

| 趋势 | 说明 |
```

## Parameters

- `--time-filter`: week (default), day, month, year
- `--limit`: max posts per subreddit (default: 10)
- `--delay`: seconds between requests (default: 3, min: 1)
- `--output-format`: json, csv, or both

## Notes

- ScrapiReddit fetches from Reddit's public JSON API
- No API key required
- Respect rate limits (3+ seconds delay recommended)
- Data saved to `./scrapi_reddit_data/` by default
