#!/usr/bin/env python3
"""
Reddit Fetcher - Native Python implementation
Zero dependencies (except requests)
"""

import argparse
import json
import time
import os
from pathlib import Path
from typing import List, Dict, Any, Optional
from urllib.parse import urlencode

# Try to import requests, provide fallback error message
try:
    import requests
except ImportError:
    print("Error: 'requests' library is required.")
    print("Install with: pip install requests")
    exit(1)


class RedditFetcher:
    """Fetch Reddit posts without external dependencies."""
    
    BASE_URL = "https://www.reddit.com"
    DEFAULT_USER_AGENT = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    )
    
    def __init__(self, delay: float = 3.0, verify_ssl: bool = True):
        self.delay = max(delay, 1.0)
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": self.DEFAULT_USER_AGENT,
            "Accept": "application/json",
            "Accept-Language": "en-US,en;q=0.8",
        })
        self.session.verify = verify_ssl
    
    def fetch_subreddit(
        self, 
        subreddit: str, 
        time_filter: str = "week",
        limit: int = 10
    ) -> List[Dict[str, Any]]:
        """Fetch top posts from a subreddit."""
        
        url = f"{self.BASE_URL}/r/{subreddit}/top/.json"
        params = {
            "t": time_filter,
            "limit": min(limit, 100),
            "raw_json": 1
        }
        
        try:
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            data = response.json()
            
            posts = []
            for child in data.get("data", {}).get("children", []):
                post_data = child.get("data", {})
                posts.append({
                    "title": post_data.get("title", ""),
                    "url": f"https://www.reddit.com{post_data.get('permalink', '')}",
                    "score": post_data.get("score", 0),
                    "num_comments": post_data.get("num_comments", 0),
                    "author": post_data.get("author", ""),
                    "subreddit": post_data.get("subreddit", ""),
                    "selftext": post_data.get("selftext", "")[:500],  # Truncate long text
                    "created_utc": post_data.get("created_utc", 0),
                })
            
            time.sleep(self.delay)
            return posts
            
        except requests.exceptions.RequestException as e:
            print(f"Error fetching r/{subreddit}: {e}")
            return []
        except json.JSONDecodeError as e:
            print(f"Error parsing JSON from r/{subreddit}: {e}")
            return []
    
    def fetch_multiple(
        self,
        subreddits: List[str],
        time_filter: str = "week",
        limit: int = 10
    ) -> Dict[str, List[Dict[str, Any]]]:
        """Fetch posts from multiple subreddits."""
        results = {}
        for subreddit in subreddits:
            print(f"Fetching r/{subreddit}...")
            results[subreddit] = self.fetch_subreddit(subreddit, time_filter, limit)
        return results


def save_json(data: Dict, filepath: Path):
    """Save data to JSON file."""
    filepath.parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def save_csv(posts: List[Dict], filepath: Path):
    """Save posts to CSV file."""
    import csv
    filepath.parent.mkdir(parents=True, exist_ok=True)
    
    if not posts:
        return
    
    fieldnames = ["title", "url", "score", "num_comments", "author", "subreddit", "selftext"]
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for post in posts:
            writer.writerow({k: post.get(k, "") for k in fieldnames})


def main():
    parser = argparse.ArgumentParser(description="Fetch Reddit posts")
    parser.add_argument(
        "--subreddits",
        default="PromptEngineering,ClaudeAI,google,Anthropic,notebooklm,SideProject,Entrepreneur,marketing",
        help="Comma-separated list of subreddits"
    )
    parser.add_argument("--time-filter", default="week", choices=["hour", "day", "week", "month", "year"])
    parser.add_argument("--limit", type=int, default=10, help="Max posts per subreddit")
    parser.add_argument("--delay", type=float, default=3.0, help="Seconds between requests")
    parser.add_argument("--output", default="./reddit_data", help="Output directory")
    parser.add_argument("--format", default="both", choices=["json", "csv", "both"], help="Output format")
    
    args = parser.parse_args()
    
    subreddits = [s.strip() for s in args.subreddits.split(",")]
    output_dir = Path(args.output)
    
    fetcher = RedditFetcher(delay=args.delay)
    results = fetcher.fetch_multiple(subreddits, args.time_filter, args.limit)
    
    # Save individual subreddit files
    for subreddit, posts in results.items():
        if args.format in ("json", "both"):
            save_json(posts, output_dir / f"{subreddit}_top_{args.time_filter}.json")
        if args.format in ("csv", "both"):
            save_csv(posts, output_dir / f"{subreddit}_top_{args.time_filter}.csv")
        print(f"  ✓ r/{subreddit}: {len(posts)} posts")
    
    # Save combined file
    if args.format in ("json", "both"):
        save_json(results, output_dir / f"all_subreddits_top_{args.time_filter}.json")
    
    print(f"\nDone! Data saved to {output_dir}")


if __name__ == "__main__":
    main()
